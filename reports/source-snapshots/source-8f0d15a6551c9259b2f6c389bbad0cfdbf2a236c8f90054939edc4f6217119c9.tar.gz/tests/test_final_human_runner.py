import importlib.util
from pathlib import Path
import pytest

spec = importlib.util.spec_from_file_location(
    "final_runner", Path(__file__).parents[1] / "tools/run_final_human_jobs.py"
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_final_report_must_match_source_lock_seed_protocol_and_cohort():
    job = dict(phase="one_step", protocol="known_users", seed=20261015, embargo_hours=24)
    report = dict(
        status="complete",
        source_digest="source",
        analysis_freeze_digest="freeze",
        seed=20261015,
        protocol="known_users",
        split="test",
        feedback_embargo_hours=24,
    )
    module.validate_result(job, report, "source", "freeze")
    for key, value in [
        ("source_digest", "changed"),
        ("seed", 20261016),
        ("feedback_embargo_hours", 0),
        ("split", "validation"),
    ]:
        with pytest.raises(ValueError):
            module.validate_result(job, dict(report, **{key: value}), "source", "freeze")
    response = dict(job, phase="response_heldout_groups")
    with pytest.raises(ValueError):
        module.validate_result(
            response, dict(report, phase="response_all_groups"), "source", "freeze"
        )
