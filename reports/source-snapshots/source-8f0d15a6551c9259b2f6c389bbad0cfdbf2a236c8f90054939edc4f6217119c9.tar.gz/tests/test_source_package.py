import importlib.util
from pathlib import Path
import io
import json
import tarfile
import pytest

spec = importlib.util.spec_from_file_location(
    "source_packager", Path(__file__).parents[1] / "tools/package_source.py"
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_archive_is_deterministic_includes_formal_and_excludes_human_rows_and_weights(tmp_path):
    for name, contents in [
        ("src/example.py", "print(1)"),
        ("formal/Bounds.lean", "example : True := by trivial"),
        ("data/synthetic/fixtures/a.json", "{}"),
        ("data/private/rows.parquet", "private"),
        ("reports/private/model.pt", "weights"),
        ("src/example.egg-info/PKG-INFO", "generated metadata"),
        (".env", "secret"),
    ]:
        p = tmp_path / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(contents)
    first, manifest = module.package(tmp_path)
    second, _ = module.package(tmp_path)
    assert first == second
    with tarfile.open(fileobj=io.BytesIO(first), mode="r:gz") as tar:
        names = tar.getnames()
        assert names == sorted(names)
        assert set(names) == {
            "src/example.py",
            "formal/Bounds.lean",
            "data/synthetic/fixtures/a.json",
            "reports/source-manifest.json",
        }
        assert json.load(tar.extractfile("reports/source-manifest.json")) == manifest
        assert all(m.mtime == 0 for m in tar.getmembers())


def test_symlink_and_unexpected_binary_in_source_directory_rejected(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "secret").write_text("secret")
    p = tmp_path / "src/leak.py"
    p.symlink_to(tmp_path / "secret")
    with pytest.raises(ValueError, match="symlink"):
        module.collect_sources(tmp_path)
    p.unlink()
    (tmp_path / "src/weights.npz").write_bytes(b"private")
    with pytest.raises(ValueError, match="non-source"):
        module.collect_sources(tmp_path)
