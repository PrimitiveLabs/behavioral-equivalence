# Mechanically checked bounds

`BehavioralBounds.lean` is checked with Lean 4.19.0 and mathlib commit `c44e0c8ee63ca166450922a373c7409c5d26b00b` (tag `v4.19.0`). All four initial lemmas passed the pinned cloud checker. Their reported dependencies are the standard Lean foundations `propext`, `Classical.choice` and `Quot.sound`. No project axioms, `sorry` or `sorryAx` are accepted.

The module proves the induction from a uniform match-probability recurrence, its observable-event error consequence, interval expansion under an absolute discrepancy allowance, and exact equality when event discrepancy is zero. It works over real numbers, not a finite numerical sample of horizons.

The coupling construction that supplies the recurrence and event-indicator inequality remains an analytical proof obligation. Statistical assumptions, human model validity and numerical implementation soundness are also outside this module. Passing these lemmas is not a complete mechanization or independent review of the research framework.

With authenticated Modal access, run:

```sh
modal run --detach cloud/check_formal_bounds.py
```

The controller downloads and checks the pinned public toolchain on Modal. It records source hashes, compiler version, theorem dependencies and output in a private research artifact. It reads no human data and makes no model-provider calls. See `configs/formal-bounds-v1.json` for the exact scope and bounded-attempt reservation.
