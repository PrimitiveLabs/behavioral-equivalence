"""CPU component tests independent of GPU allocation availability."""

from pathlib import Path
import modal

ROOT = Path(__file__).resolve().parents[1]
app = modal.App("behavioral-equivalence-neural-component-tests-v1")
volume = modal.Volume.from_name("behavioral-equivalence-research", create_if_missing=True)
image = (
    modal.Image.debian_slim(python_version="3.11")
    .pip_install("torch==2.7.1", "numpy==2.2.6", "pytest==8.4.1")
    .env({"PYTHONPATH": "/research/src", "OMP_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "1"})
    .add_local_dir(ROOT / "src", remote_path="/research/src")
    .add_local_file(
        ROOT / "tests/test_exposure_neural.py",
        remote_path="/research/tests/test_exposure_neural.py",
    )
)


@app.function(
    image=image,
    cpu=(2, 2),
    memory=(2048, 2048),
    timeout=120,
    max_containers=1,
    retries=0,
    volumes={"/artifacts": volume},
)
def run() -> dict:
    import hashlib
    import json
    import subprocess

    sources = {
        "check_neural_models.py": Path(__file__).read_text(),
        "test_exposure_neural.py": Path("/research/tests/test_exposure_neural.py").read_text(),
    }
    for name in ["neural.py", "exposure_neural.py"]:
        sources[name] = (Path("/research/src/behavioral_equivalence") / name).read_text()
    digest = hashlib.sha256(json.dumps(sources, sort_keys=True).encode()).hexdigest()
    result = subprocess.run(
        ["python", "-m", "pytest", "-q", "-W", "error", "/research/tests/test_exposure_neural.py"],
        capture_output=True,
        text=True,
        timeout=90,
    )
    report = {
        "status": "complete" if result.returncode == 0 else "failed",
        "source_digest": digest,
        "returncode": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
        "scope": "CPU component predictions, gradients and evaluation repeatability; not GPU throughput or full fitted-model validation",
    }
    out = Path("/artifacts/neural-component-tests-v1") / digest
    out.mkdir(parents=True, exist_ok=True)
    (out / "source.json").write_text(json.dumps(sources, indent=2))
    (out / "report.json").write_text(json.dumps(report, indent=2))
    volume.commit()
    return report


@app.local_entrypoint()
def main():
    import json

    call = run.spawn()
    print(
        json.dumps({"function_call_id": call.object_id, "function_id": run.object_id}), flush=True
    )
    result = call.get()
    print(json.dumps(result, indent=2), flush=True)
    if result["status"] != "complete":
        raise RuntimeError("Neural component tests failed")
