# Behavioral equivalence under uncertainty

Primitive Labs end-to-end research workspace. Status: implementation and cloud engineering pilots underway. Measured findings are in [pilot results](reports/pilot-results.md). The full synthetic verification matrix is running. The frozen synthetic uncertainty campaign has completed; confirmatory human evaluation remains pending.

Start with [the execution architecture](docs/goal-architecture.md), [the dependency manifest](configs/program.json), and [execution state](reports/execution-state.json). Inspect [cloud jobs](reports/cloud-jobs.json) for actual submitted work and retained failures.

Scope: all nine deliverables, all four experiments, mathematical proofs, synthetic benchmarks, real human training, transition uncertainty, intervention transfer, measured publication figures, and a reproducible release package. The persistent Codex goal remains active until the full completion contract is met.

## Local controls

```
uv sync --group dev
uv run pytest -q -W error
uv run ruff check src tests cloud
uv run python -m behavioral_equivalence plan
```

The planner validates all dependencies and lists eligible work. It does not submit jobs. Source-bound synthetic campaign controllers persist call handles and conservative budget reservations. A generic resumable DAG runner remains incomplete.

## Implemented evidence

Small rational certificates and a corruption checker live under `data/synthetic/fixtures` and `src/behavioral_equivalence/rational.py`. [Proof drafts](spec/proofs.md) remain independently unreviewed.

The [synthetic engineering pilot](reports/preflight/synthetic-pilot.json) contains 80 PRISM 4.11 nominal comparisons across five mechanism families, plus an independently checked positive-lower-bound interval fixture. It has zero numerical bound violations at tolerance 1e-10. The largest PRISM/dynamic-programming difference is 4.44e-16. This is not the full synthetic benchmark or a general floating-point soundness certificate. PRISM's interval engine rejects represented zero-lower-bound edges; the new directed-integer engine supports those rows, with a separate exact-arithmetic certificate and uniform abstraction envelope.

KuaiRand-1K lives on Modal, with a verified official archive checksum. The [observation policy](spec/data-observation-policy.md) documents timestamp ties, outcome timing, license evidence and pilot isolation. The v2 preprocessing output is diagnostic only because it discards 97.8% of raw interactions; v4 preserves unordered timestamp bundles and all 19 official source fields. Six baseline model/protocol fits, paired fixed-model analyses and exploratory quantization comparisons are complete. Nested latent refinement and exact numerical certification are implemented; strict and finite-property certified compression pilots both fail the 2x target. Final confirmatory fidelity remains open.

Keep expensive data, training, solvers, and statistical workloads on cloud compute. Store immutable research evidence separately from product data. Never infer scientific success from a task-completion status.

## Current human-data and publication artifacts

The full KuaiRand-27K candidate has 309,105,777 deduplicated interactions, 53,720,429 timestamp bundles and 26,285 nonpilot users. The [independent full-data audit](reports/preflight/kuairand-27k-independent-audit.json) passes. [Shared-calendar support](reports/preflight/kuairand-27k-calendar-support.json) and [bounded case construction](reports/preflight/kuairand-27k-confirmatory-cases.json) are complete under 0-, 24- and 48-hour feedback embargo assumptions. The independent full sampled-case audit passes. Model/analysis preregistration and multi-seed final evaluation remain pending; no final predictive scores have been inspected.

The earlier 1K per-user chronological fits are exploratory retrospective comparisons. Final cases use shared UTC cutoffs across users, recorded in the [calendar contract](spec/confirmatory-calendar.md). Actual feedback observation timestamps remain unavailable. The [canonical mathematical contract](spec/model.md) separates specified-model guarantees from human evidence.

[Figure 04](reports/figures/figure-04/figure04-da567fa770d4/figure-04-uncertainty.pdf) contains measured synthetic uncertainty results and a [caption](reports/figures/figure-04/figure04-da567fa770d4/caption.md). One of six required core figures is available. The full-matrix integer audit follows the live E1 campaign and persists source-bound per-world evidence.

Provider constraint: GPT-6.1 and Claude API calls are prohibited throughout this program. No provider inference calls have been made. Modal supplies research compute; research-isolated R2 holds permitted aggregate evidence.
