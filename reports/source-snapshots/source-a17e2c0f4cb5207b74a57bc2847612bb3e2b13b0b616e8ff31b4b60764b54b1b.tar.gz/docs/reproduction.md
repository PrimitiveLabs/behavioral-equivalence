# Reproduction and recovery

The source package contains the complete implementation, tests, pinned study configurations, Lean proofs and rights notices. The measured result package is separate. Neither includes raw human data, individual forecasts, trained weights, credentials or runtime ledgers.

## Fresh public scientific check

Install the pinned Python dependencies and run the complete tests, then invoke tools/scientific_reproduction.py with the official checksum-pinned PRISM 4.11 binary. This script generates ten fresh 32-state worlds spanning all five mechanisms and exact/perturbed regimes, runs all six abstraction-method families at four horizons, recomputes certificates and makes 20 external PRISM queries. It is a small scientific reproduction, not a second 1200-world campaign. The original full matrix and independent 26,400-certificate audit remain separate measured artifacts.

```sh
uv sync --group dev
uv run pytest -q -W error
uv run ruff check src tests cloud tools
uv run python tools/scientific_reproduction.py --output reports/fresh-scientific-run --prism /path/to/prism/bin/prism
```

Optional neural/data tests require the pinned Torch, scikit-learn, Polars, DuckDB and PyArrow versions listed in cloud/reproduce_source_package.py. The release cloud check builds a wheel, confirms imports resolve to that installed wheel, disables source-path injection, requires zero skipped tests and runs the scientific subset in a temporary fresh environment. Its report binds the archive, checker source, wheel, dependency versions, command logs and scientific artifacts.

## Full recorded campaigns

configs/program.json and docs/goal-architecture.md describe the entire dependency graph. Frozen per-campaign protocols retain all seeds, sizes, tolerances, estimands and resource reservations. The full synthetic matrix is configs/synthetic-main-v3.json; uncertainty, nominal-control, intervention and diversity protocols are separate. Do not multiply horizons into independent world counts or treat reused diversity worlds as fresh samples.

Human reproduction requires the official licensed dataset and the source-bound private Modal layout. Dataset roots, calibration/fit artifacts and exact output hashes are in the frozen configurations and source snapshots. Acquire data from its official distribution, honor dataset-specific terms and preserve pilot exclusion, calendar roles, vocabulary construction and outcome availability. Public source does not grant access to private volumes or silently recreate missing human evidence.

The 50-job primary runner is tools/run_final_human_jobs.py. Supplementary heads/calibration, final six-endpoint scores and joint trajectories have separate source-bound controllers. The primary pre-test lock is immutable; supplementary studies remain exploratory. Run the saved frozen source for an existing campaign, rather than editing a historical configuration to fit a new environment. An unprovided generic cold-start DAG submitter is not claimed: the complete study uses explicit campaign controllers and dependency/evidence manifests.

## Recover existing calls safely

Retain each original provider call ID. Attach to a live call or retrieve its terminal report. A local timeout, network error or missing observation is not evidence that execution stopped. Lifetime launcher locks and exclusive submission-attempt markers prevent replacement submission while outcome is uncertain. Inspect provider history if a marker exists without a saved handle. Do not delete locks/markers to force a retry or promote an observation error to terminal failure.

Budget ledgers reserve conservative campaign costs atomically and reject increases past their existing ceiling. Reservations are not posted spending, credits, net invoices or provider-enforced global caps. No frontier provider calls or external language-model inference are needed. GPU training and CPU verification run on Modal; permitted archives use the isolated private R2 bucket with readback checksums.

The reports/evidence-registry.json inventory checks artifact identity, not scientific completion. Use native certificate replay, complete empirical result matrices and the original claim scopes as well. A model-level error certificate cannot establish that human behavior belongs to its model family.
