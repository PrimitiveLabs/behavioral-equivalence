import json
from copy import deepcopy
from pathlib import Path
import pytest
from behavioral_equivalence.__main__ import plan


def test_full_campaign_plan_and_rejection_of_broken_dependencies():
    config = json.loads(Path("configs/program.json").read_text())
    summary = plan(config)
    assert summary["deliverable_count"] == 9
    assert summary["task_count"] == 34
    assert summary["submission"] == "disabled in planner"
    broken = deepcopy(config)
    broken["tasks"][0]["depends_on"] = ["R04"]
    with pytest.raises(ValueError, match="cycle"):
        plan(broken)
    broken["tasks"][0]["depends_on"] = ["missing"]
    with pytest.raises(ValueError, match="Missing"):
        plan(broken)
