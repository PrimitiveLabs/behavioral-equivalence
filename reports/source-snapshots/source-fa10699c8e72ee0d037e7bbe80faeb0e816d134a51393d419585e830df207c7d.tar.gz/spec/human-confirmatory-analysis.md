# Confirmatory human comparison and decision rules

Status: candidate analysis contract, not the final immutable analysis freeze. No final human predictive scores have been inspected. Final artifact hashes, abstraction operating-point rules and supported multistep cohorts must be frozen before test scoring. Positive scientific outcomes are not required for completing the experiment.

## Population, observations and comparators

Use the independently audited nonpilot 27K cohort and shared UTC calendar. The primary feedback timing policy is summed bundle-duration availability plus 24 hours. Zero- and 48-hour policies are sensitivity analyses on their own recorded case sets. They are overlapping observations, not independent replications. Actual feedback observation provenance remains unavailable.

Cases are the immutable per-user capped samples. All comparators receive identical case IDs within a protocol and timing policy. Known-user and unseen-user protocols are reported separately. Unseen-user fitting requires the declared user/calendar roles to agree. Model inputs exclude user identity, current feedback, unavailable historical feedback, random-exposure flag and full-period response statistics.

Compare the finite-order Markov baseline, a current-context-only neural predictor, GRU and Transformer predictors, the full discrete parent, independently fitted quantizations and nested parent-state reductions. Context-only, GRU and Transformer models share training-only current-item vocabularies and intrinsic duration context. Missing/too-recent metadata remains explicit. The context-only comparator omits behavioral history. Model capacities and exact parameter counts are reported; shared large item tables do not make different encoders exactly capacity matched.

Use five fixed fitted seeds, 20261015 through 20261019. The initial immutable matrix contains the first three; a separate source-bound supplement contains the last two. This supplement preserves the architecture document's five-seed robustness target and adds no selected favorable seeds. All five enter every final decision. It is declared while initial training/validation runs are underway and before any final predictive test scoring. Checkpoint selection uses the lowest equal-user validation NLL among three fixed training epochs, with earliest-epoch tie breaking. Hardware and numeric precision must be recorded before fitting. A hardware change cannot silently change case counts, architectures, epochs or seed lists.

## Learned parent and abstraction scope

The primary parent uses the GRU predictor's 128-dimensional penultimate MLP activation. Fit its state quantizer and representation normalizers on training data only. The K256 parent is the reference discrete model. Evaluate K in 16,32,64,128,256 for independent quantization baselines. Report parent-versus-continuous predictive loss so a weak discretization cannot conceal degradation relative to the strong sequence comparators.

Nested methods merge parent states and retain their explicit maps. Exact/approximate bisimulation and direct finite-property certificates have different claim scopes. All point-model certificates refer to the actual estimated, normalized finite kernel. Human transition samples are dependent and the representation is learned; no fixed-iid-row statistical coverage claim is imported from the synthetic experiment.

Transition estimation must use adjacent, exposure-indexed timestamp bundles, with one outcome-independent random representative exposure per bundle. Randomly sampled nonadjacent prediction cases cannot stand in for consecutive transitions. The current bundle's eventual response can enter a joint transition factorization, but cannot enter the next encoder until the declared feedback availability permits it. This retrospective factorization is not a causal behavioral policy.

Calibration can estimate the point-model transition kernel after encoders and quantizers freeze. A point-model property check remains valid after selecting a partition, because it checks the actual selected kernel. That fact does not establish a statistical confidence set for the unknown human process. Any stronger uncertainty claim requires its own valid sampling/selection argument or fresh data.

## Primary noninferiority estimand

For each user, calculate the mean paired difference in next-response NLL on that user's sampled test cases. Average those means equally across supported users. Clip both probability vectors to [1e-6,1-1e-6] when calculating NLL, with the same rule for all models. Case-weighted NLL and Brier scores are secondary descriptions.

For each fixed fitted seed and protocol, use a paired user-cluster bootstrap with 2,000 replications and prespecified seed 20261015. The candidate is noninferior only if the upper endpoint of its two-sided 95% interval is strictly below 0.01 additional nats per prediction. Report the complete interval and point difference, including statistically detectable loss increases that remain within the margin.

The compression target is at least 2x relative to the same K256 parent, or at most 128 reduced latent states. The primary success declaration requires both compression and noninferiority for every predeclared fitted seed in both evaluation protocols. A noninferior identity partition fails compression. A smaller separately refitted quantizer is not a successful nested certified quotient.

This is an intersection-union decision over the fixed fitted models: all required conditions must pass. A favorable seed is insufficient. Report between-seed variation and paired averages descriptively. These conditional intervals do not estimate the population of all possible training seeds. Comparisons against the continuous models and other methods retain their own reference labels and are not relabeled as the primary test.

## Operating-point selection and secondary analyses

Choose a single primary operating point per seed/protocol using development/validation evidence before opening final scores. Freeze the exact tolerance grid, finite property suite, fallback if no candidate meets validation criteria, tie breaking and compute budgets in the final analysis manifest. Do not expand tolerances until final compression succeeds. Report all frozen operating points descriptively as a frontier even when the primary decision fails.

Match random, embedding and predictive-distribution controls to the same parent and reduced state counts. Controls receive the same additional calibration/refinement observations and tuning budgets. Also report independent quantizations as a distinct baseline class. Finite-property certification is not a substitute for a failed strict-bisimulation result.

Report calibration in 20 fixed probability bins with equal-user weights, alongside support counts. Cohort comparisons by tab or history length require at least 50 users and 2,000 prediction cases; unsupported cells are reported without inferential claims. Retain rare-state frequency and missing-context summaries. Disclose common calendar/environment dependence beyond user clustering.

For multistep outcomes, define a prespecified observable event, origin rule and decision horizon before scoring. Report observation support and right-censoring at each horizon. Restricting to users with H future recorded bundles creates a conditional observed-horizon cohort; it is not an unconditional survival or intentional-abandonment estimand. Future-label events are indexed by exposure decisions and eventual recorded feedback, not necessarily by when that feedback becomes available online.

Human uncertainty evaluation must compare the appropriate cohort event-probability estimand with aggregated observations and their sampling uncertainty. Containment of one binary response in a probability interval is not a confidence-coverage test. Model-level uncertainty, empirical calibration and observational selection are reported separately.

Supported intervention prediction uses a separate frozen design and actual randomized-exposure observations, as specified in [the intervention contract](intervention-estimand.md). It cannot establish arbitrary-interface or multi-step counterfactual transfer. No human transfer claim follows from synthetic witnesses alone.

## Remaining final-freeze requirements

The confirmatory analysis is not ready to score final tests until the exact source/model/case hashes, quantizer construction, transition cohort, primary abstraction selection rule, complete baseline and ablation grid, supported multistep origins, statistical resampling configuration, intervention separation and hardware/numeric policy are recorded immutably. Any later deviation receives a dated sidecar and an exploratory label.
