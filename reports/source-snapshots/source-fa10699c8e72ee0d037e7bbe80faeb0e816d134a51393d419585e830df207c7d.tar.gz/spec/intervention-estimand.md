# Supported human intervention estimand

Status: design draft. Assignment verification, overlap audit and confirmatory power remain open. This document does not establish a human transfer result.

## Observable target and assignment

KuaiRand's official description records random replacement of recommended items from a candidate pool: https://github.com/chongminggao/KuaiRand . Its `is_rand` flag identifies intervened exposures. The observed overall fraction of random records is not a known individual propensity. Do not substitute that fraction into an inverse-propensity estimator without evidence of the assignment mechanism and eligible population. The 15 tab/scenario policies also require separate support checks.

The initial supported outcome is the recorded click/valid-play response to an individual exposed item. Analyses stratify by documented scenario and retain user-clustered sampling. Concurrent exposures share the same pre-timestamp history. Full-period item popularity, realized watch duration and post-assignment feedback never become pretreatment predictors.

A candidate intervention family changes the distribution over item groups in the documented randomized pool. Groups must use stable item metadata known at exposure time, such as verified video-duration bins, or a grouping frozen from training-only item information. The current `duration_ms` log column cannot automatically establish feature availability. Verify its agreement with stable item metadata, upload dates and the assignment pool before using it as context.

## Identification boundary

For randomized items, evaluate observed outcomes under supported group exposure conditions on independent users/times. If uniform selection from a fixed pool is established, calculate a group's assignment probability from the actual eligible pool membership, with separate scenario/time pools if necessary. Check consistency, missing outcomes, treatment support, contemporaneous exposure dependence and whether pool membership changes. If uniform selection or eligibility is not documented adequately, report a conditional observed-response prediction comparison and avoid a causal effect claim.

Do not treat randomized item exposure as randomization of arbitrary checkout designs, interfaces, fees or entire future recommendation trajectories. A one-exposure intervention evaluation supports a one-step response claim. Multi-step counterfactual trajectory evaluation requires sequential assignment and overlap assumptions or a separate authorized product experiment. Record this as a separate scope limitation even if one-step transfer succeeds.

## Frozen evaluation design

Train behavioral encoders on the designated training observations. Learn initial abstractions under training exposure environments. Define candidate environment groups using training data, fix search budgets and baselines, and select witnesses using only the search/validation observations. Compare a proposed state-pair's disagreement on prespecified outcomes, not arbitrary post hoc psychological interpretations.

Refine the partition using the same additional observations available to controls. Include random splits, extra states without targeted splits, extra data without refinement, random environment selection, fixed grids, a simple active-design baseline, and strong continuous sequence predictors. Match sample budgets, state capacity and tuning effort.

Freeze the chosen groups, target, horizon, weighting, model fits and tests before opening final intervention observations. Evaluate on held-out randomized observations with user-level clustering. Keep discovery data separate from certification calibration; use fresh calibration or a guarantee that covers adaptive selection. Never repeatedly tune on final intervention outcomes.

Primary result: paired user-weighted change in proper prediction loss on independent supported intervention responses, with confidence intervals and a multiplicity policy. Report group counts, user counts, effective sample sizes, overlap, width of intervals, and rare-state exclusions. A state pair that looks different in a learned simulator is a candidate witness; real outcomes must establish whether the distinction improves human prediction.

## Data checks still required

Reconcile the official random-pool size with observed item identifiers and release reindexing. Audit random versus standard records by date and tab. Establish whether repeated user/item/timestamp records represent duplication or distinct logged observations. Establish the mapping of pilot users to the 27K release before final user exclusion. Determine power from pilot per-user variance and the actual supported intervention counts. If the data cannot support identification or power, preserve the open human-transfer dependency and report the narrower empirical or synthetic result honestly.

## Assignment evidence checked on 2026-10-15

Section 3.2 of the [dataset paper](https://arxiv.org/html/2208.08696) describes list-level insertion with a fixed but undisclosed probability, replacement of a randomly selected list position, and uniform item choice from 7,583 videos. It also states that the released users were retained only after at least ten random exposures. The release therefore selects users using their realized full-period exposure history.

Conditional item probability in the documented source mechanism is 1/7,583. It is different from the unknown probability of selecting an impression for replacement. Neither the published overall replacement fraction nor a fitted flag classifier supplies the withheld list-level probability. Release selection can further affect ignorability, especially if earlier interventions change later participation. A causal off-policy claim requires an explicit argument addressing that selection, list context and sequential eligibility.

The currently feasible human experiment evaluates predictions on observed random-exposure responses in the released cohort, with separate item-group and scenario support checks. Its scope is conditional observed-response prediction under the documented intervention data. It does not establish population treatment effects, arbitrary interface transfer, or counterfactual multi-step trajectories. Current-item identity is available as exposure context; month-aggregated item response statistics are excluded as future-derived features.

## Measured pool context audit

The full random-source item IDs reconcile to 7,583. The checksum-bound basic metadata has every reindexed item ID. Among pool items, usable positive durations are available for 7,344 items and unavailable for 239. Four prespecified duration groups, at most 7 seconds, 7 to 18 seconds, 18 to 60 seconds, and over 60 seconds, contain 42, 997, 1,775 and 4,530 items respectively. At 1,149,139 random-source rows with both durations usable, logged and basic-metadata durations match exactly. These are context-consistency checks, not outcome or causality evidence.

Any eventual known-duration-pool analysis must state its restriction explicitly and preserve the unknown-duration group in the support report. Conditional uniform source item assignment does not resolve release-cohort selection or identify the withheld list-insertion probability. Standard-case metadata agreement and final intervention case/power audits remain open. See `reports/preflight/kuairand-27k-item-metadata-audit.json`.
